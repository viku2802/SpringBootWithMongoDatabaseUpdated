/***
 *  (c) Copyright FUJITSU NETWORK COMMUNICATIONS
 *  All Rights Reserved
 * 
 * <b>Author</b> 				: Praveen Mandadi <br>
 * <b>Class Description</b> 	: WebConfig server for live data processing from server to UI <br>  
 * <b>Date</b>   				: 27-Dec-2019 <br>
 * <b>Updated</b>				: 27-Dec-2019 <br>
 */

package com.fujitsu.fnc.alarmmanagement.nb.api.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@EnableWebSocketMessageBroker
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Configuration
public class WebConfig implements WebSocketMessageBrokerConfigurer{
	
	@Override
    public void registerStompEndpoints(StompEndpointRegistry stompEndpointRegistry) {
        stompEndpointRegistry.addEndpoint("/socket").setAllowedOrigins("*")
                .withSockJS();
    }

	
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic");
    }
     
}
