package com.fujitsu.fnc.alarmmanagement.nb.api.service;

import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.search.suggest.SortBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import com.datastax.oss.driver.api.core.cql.PagingState;
import com.fujitsu.fnc.alarmmanagement.nb.api.model.AlarmManagement;
import com.fujitsu.fnc.alarmmanagement.nb.api.model.CSVHelper;
import com.fujitsu.fnc.alarmmanagement.nb.api.repository.AlarmManagementRepository;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

@Service
@Configuration
public class AlarmManagementService {

	private static Logger logger = LogManager.getLogger(AlarmManagementService.class);

	@Autowired
	AlarmManagementRepository alarmManagementRepository;

	public AlarmManagement getAlarmDetails(String aid) {

		AlarmManagement alarmManagement = alarmManagementRepository.findByAid(aid);

		return alarmManagement;

	}

	public AlarmManagement alarmManagementServiceSchedule(@Valid AlarmManagement alarmManagement) {
		alarmManagement.setId(UUID.randomUUID());
		alarmManagementRepository.save(alarmManagement);
		return alarmManagement;
	}

	public AlarmManagement getTid(String aid) {

		AlarmManagement alarmManagement = alarmManagementRepository.findByAid(aid);

		return alarmManagement;

	}

	public List<AlarmManagement> getAlarmDetailsUsingSeverity(String severity) {

		return alarmManagementRepository.findBySeverity(severity);

	}

	public Long countSeverityDetails(String severity) {
		return alarmManagementRepository.count(severity);

	}

	public List<AlarmManagement> getAlarmDetailsUsingTid(String tid) {

		return alarmManagementRepository.findByTid(tid);

	}

	/*
	 * public List<String> searchPerson(String queryString) {
	 * 
	 * List<String> result = alarmManagementRepository.severity(queryString);
	 * 
	 * int critical=0; int noramal; for(String sev : result) { if("MJ".equals(sev))
	 * critical+=1;
	 * 
	 * }
	 * 
	 * 
	 * return result; }
	 */

	public ByteArrayInputStream load() {
		List<AlarmManagement> alarmManagementList = alarmManagementRepository.findAll();

		ByteArrayInputStream in = CSVHelper.alarmDetailsToCSV(alarmManagementList);
		return in;
	}

	public Slice<AlarmManagement> findAll(Pageable pageable) {
		return alarmManagementRepository.findAll(pageable);
	}

	public long count() {
		return alarmManagementRepository.count();
	}

}
