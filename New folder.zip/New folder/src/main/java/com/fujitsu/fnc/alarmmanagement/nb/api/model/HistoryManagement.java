package com.fujitsu.fnc.alarmmanagement.nb.api.model;

import java.sql.Timestamp;
import java.util.UUID;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Data;
@Data
@Table("Historic")
public class HistoryManagement {
	@PrimaryKeyColumn(name="id",ordinal =0, type=PrimaryKeyType.PARTITIONED)
	private UUID id;
	@PrimaryKeyColumn(name="aid",ordinal =1, type=PrimaryKeyType.CLUSTERED)
	private String aid;
	@PrimaryKeyColumn(name="tid",ordinal =2, type=PrimaryKeyType.CLUSTERED)
	private String tid;
	private String aidType;
	@PrimaryKeyColumn(name="timestamp",ordinal =3, type=PrimaryKeyType.CLUSTERED)
	private Timestamp timestamp;
	private String severity;
	private String conditionDesc;
	private String location;
	private String direction;
	private String serviceEffected;
	@PrimaryKeyColumn(name="faultType",ordinal =4, type=PrimaryKeyType.CLUSTERED)
	private String faultType;
	private String conditionEffect;
	private String aidDetail;
	private String nmsRaisedDatTime;
	@Override
	public String toString() {
		return "HistoryManagement [id=" + id + ", aid=" + aid + ", tid=" + tid + ", aidType=" + aidType + ", timestamp="
				+ timestamp + ", severity=" + severity + ", conditionDesc=" + conditionDesc + ", location=" + location
				+ ", direction=" + direction + ", serviceEffected=" + serviceEffected + ", faultType=" + faultType
				+ ", conditionEffect=" + conditionEffect + ", aidDetail=" + aidDetail + ", nmsRaisedDatTime="
				+ nmsRaisedDatTime + "]";
	}
	
	

}
