package com.fujitsu.fnc.alarmmanagement.nb.api.repository;

import java.util.List;

import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fujitsu.fnc.alarmmanagement.nb.api.model.AlarmManagement;
import com.fujitsu.fnc.alarmmanagement.nb.api.model.HistoryManagement;

@Repository
public interface HistoryManagementRepositiory extends CassandraRepository<HistoryManagement, String> {

	@AllowFiltering
	HistoryManagement findByAid(String aid);
	
   

	@AllowFiltering
	List<HistoryManagement> findBySeverity(String severity);
	
	
	@Query(value = "SELECT count(*) FROM historic where severity = ?0 Allow Filtering")
	public Long count(@Param("severity") String severity);
	
	
	

	@Query(value = "SELECT severity FROM historic")
	public List<String> severity(@Param ("severity") String severity);
	   
	
	@AllowFiltering
	List<HistoryManagement> findByTid(String tid);
	
	Slice<HistoryManagement> findAll(Pageable pageable);
	
		
	}
