package com.fujitsu.fnc.alarmmanagement.nb.api.service;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;

import com.fujitsu.fnc.alarmmanagement.nb.api.model.AlarmManagement;
import com.fujitsu.fnc.alarmmanagement.nb.api.model.CSVHelper;
import com.fujitsu.fnc.alarmmanagement.nb.api.model.HistoryManagement;
import com.fujitsu.fnc.alarmmanagement.nb.api.repository.AlarmManagementRepository;
import com.fujitsu.fnc.alarmmanagement.nb.api.repository.HistoryManagementRepositiory;

@Service
@Configuration
public class HistoryManagementService {
	private static Logger logger = LogManager.getLogger(HistoryManagementService.class);

	@Autowired
	HistoryManagementRepositiory historyManagementRepositiory;

	

	public HistoryManagement getHistoryDetails(String aid) {

		HistoryManagement historyManagement = historyManagementRepositiory.findByAid(aid);

		return historyManagement;

	}

	public HistoryManagement historyManagementServiceSchedule(@Valid HistoryManagement historyManagement) {
		historyManagement.setId(UUID.randomUUID());
		historyManagementRepositiory.save(historyManagement);
		return historyManagement;
	}
	

	public HistoryManagement getTid(String aid) {

		HistoryManagement historyManagement = historyManagementRepositiory.findByAid(aid);

		return historyManagement;

	}

	
	public List<HistoryManagement> getHistoryDetailsUsingSeverity(String severity) {

		return historyManagementRepositiory.findBySeverity(severity);

	}

	
	public Long countSeverityDetails(String severity) {
		return historyManagementRepositiory.count(severity);

	}

	
	public List<HistoryManagement> getHistoryDetailsUsingTid(String tid) {

		return historyManagementRepositiory.findByTid(tid);

	}

	
	public List<String> searchPerson(String queryString) {

		List<String> result = historyManagementRepositiory.severity(queryString);
		/*
		 * int critical=0; int noramal; for(String sev : result) { if("MJ".equals(sev))
		 * critical+=1;
		 * 
		 * }
		 */
		
		return result;
	}

	
	 public ByteArrayInputStream load() {
		    List<HistoryManagement> historyManagementList = historyManagementRepositiory.findAll();
		    ByteArrayInputStream in = CSVHelper.historyDetailsToCSV(historyManagementList);
		    return in;
		  }
	  
	 
	 public Slice<HistoryManagement> findAll(Pageable pageable) {
			return historyManagementRepositiory.findAll(pageable);
		}

	 
		public long count() {
			return historyManagementRepositiory.count();
		}
		
	
}


