package com.fujitsu.fnc.alarmmanagement.nb.api;

import java.io.InputStream;
import java.util.Properties;

import org.apache.catalina.connector.Connector;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;


@SpringBootApplication
@ComponentScan("com.fujitsu.fnc.alarmmanagement")
@EnableCassandraRepositories
public class AlarmManagementApplication {
	public static Logger logselectger = null;
	private static String version;

	@Value("${http.port}")
	private int httpPort;
	public static void main(String[] args) throws Exception  {
		SpringApplication.run(AlarmManagementApplication.class, args);
	}
	public static void updateLog4jConfig() {
		Properties prop = new Properties();
		InputStream input = null;
		try {
			String filename = "application.properties";
			input = AlarmManagementApplication.class.getClassLoader().getResourceAsStream(filename);
			prop.load(input);
			ThreadContext.put("path", prop.getProperty("log.file.path"));
			version = prop.getProperty("application.version");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Let's configure additional connector to enable support for both HTTP and
	// HTTPS
	@Bean
	public ServletWebServerFactory servletContainer() {
		TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory();
		tomcat.addAdditionalTomcatConnectors(createStandardConnector());
		return tomcat;
	}

	private Connector createStandardConnector() {
		Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
		connector.setPort(httpPort);
		return connector;
	}

}
