package com.fujitsu.fnc.alarmmanagement.nb.api.model;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;

import lombok.ToString;



public class CSVHelper {

  public static ByteArrayInputStream alarmDetailsToCSV(List<AlarmManagement> alarmManagementList) {
    final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
      for (AlarmManagement alarmManagement : alarmManagementList) {
        List<String> data = Arrays.asList(
              String.valueOf(alarmManagement.getAid()),
              alarmManagement.getAidDetail(),
              alarmManagement.getAidType(),
              alarmManagement.getTid(),
              alarmManagement.getConditionDesc(),
              alarmManagement.getConditionEffect(),
              alarmManagement.getDirection(),
              alarmManagement.getLocation(),
              alarmManagement.getServiceEffected(),
              
              alarmManagement.getNeClearedDatTime(),
              
              alarmManagement.getSeverity(),
              alarmManagement.getConditionType(),
              alarmManagement.getFaultType()
            );

        csvPrinter.printRecord(data);
      }

      csvPrinter.flush();
      return new ByteArrayInputStream(out.toByteArray());
    } catch (IOException e) {
      throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
    }
  }
  
  
  public static ByteArrayInputStream historyDetailsToCSV(List<HistoryManagement> historyManagementList) {
	    final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

	    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
	        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
	      for (HistoryManagement historyManagement : historyManagementList) {
	        List<String> data = Arrays.asList(
	              String.valueOf(historyManagement.getAid()),
	              historyManagement.getAidDetail(),
	              historyManagement.getAidType(),
	              historyManagement.getTid(),
	              historyManagement.getConditionDesc(),
	              historyManagement.getConditionEffect(),
	              historyManagement.getDirection(),
	              historyManagement.getLocation(),
	              historyManagement.getServiceEffected(),
	              historyManagement.getNmsRaisedDatTime(),
	              historyManagement.getSeverity(),
	              historyManagement.getFaultType(),
	              historyManagement.getTimestamp().toString()
	            );

	        csvPrinter.printRecord(data);
	      }

	      csvPrinter.flush();
	      return new ByteArrayInputStream(out.toByteArray());
	    } catch (IOException e) {
	      throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
	    }
	  }
}


