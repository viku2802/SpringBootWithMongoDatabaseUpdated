package com.fujitsu.fnc.alarmmanagement.nb.api.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;
import org.springframework.data.domain.Slice;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fujitsu.fnc.alarmmanagement.nb.api.model.AlarmManagement;
import com.fujitsu.fnc.alarmmanagement.nb.api.model.HistoryManagement;
import com.fujitsu.fnc.alarmmanagement.nb.api.service.HistoryManagementService;

@RestController
@RequestMapping("/api/historic")
@EnableCassandraRepositories
public class HistoricManagementController {
	
	private static Logger logger = LogManager.getLogger(HistoricManagementController.class);
	private static final String DATABASE_DOWN = "Database service currently unavailable";
	@Autowired
	private HistoryManagementService historyManagementService;
	

	
	
	
	@PostMapping(value = "/v1/historic", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody HistoryManagement alarmManagementServiceSchedule(
			@Valid @RequestBody HistoryManagement historyManagement) throws Exception {
		try {
			HistoryManagement historyManagementRes = historyManagementService.historyManagementServiceSchedule(historyManagement);

			logger.info("HTTP POST SUCCESS: updated the alarmDetails, " + historyManagementRes.toString());

			return historyManagementRes;
		} catch (Exception e) {
			logger.error("HTTP POST FAILED: Couldn't updated the historyDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	

	@GetMapping(value = "/v1/historic/{aid}")
	public @ResponseBody HistoryManagement getHistoryDetails(@PathVariable("aid") String aid) throws Exception {
		try {

			HistoryManagement historyManagement = historyManagementService.getHistoryDetails(aid);

			logger.info("HTTP GET SUCCESS: historyManagement :" + historyManagement);

			return historyManagement;
		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find historyManagement ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	@GetMapping(value = "/v1/historic/tid/{aid}")
	public @ResponseBody String getTid(@PathVariable("aid") String aid) throws Exception {
		try {

			HistoryManagement historyManagement = historyManagementService.getTid(aid);

			logger.info("HTTP GET SUCCESS: historyManagement :" + historyManagement);

			return historyManagement.getTid();
		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find tidDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	@GetMapping(value = "/v1/historic/historyDetails/{severity}")
	public List<HistoryManagement> getHistoryDetailsSeverity(@PathVariable("severity") String severity)
			throws DuplicateKeyException, Exception {
		try {

			return historyManagementService.getHistoryDetailsUsingSeverity(severity);

		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find historyManagementDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}

	}

	
	@GetMapping(value = "/v1/historic/SeverityCountDetails/{severity}")
	public Long countSeverity(@PathVariable("severity") String severity) throws Exception {
		try {

			Long count = historyManagementService.countSeverityDetails(severity);
			return count;

		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find SeverityCountDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}

	}

	
	@GetMapping(value = "/v1/historic/historyDetailsByTid/{tid}")
	public List<HistoryManagement> getHistoryDetailsUsingTid(@PathVariable("tid") String tid) throws Exception {
		try {

			return (List<HistoryManagement>) historyManagementService.getHistoryDetailsUsingTid(tid);

		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find historyManagementDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	@GetMapping(value = "/v1/historic/search/{queryString}")
    public ResponseEntity<List<String>> searchPersons( @PathVariable("queryString") String queryString ) {
	List<String> persons = historyManagementService.searchPerson(queryString);
	return new ResponseEntity<List<String>>( persons , HttpStatus.OK);
     }
	 
	
	 @GetMapping(value ="/v1/historic/download-history-csv")
	  public ResponseEntity<Resource> getFile() {
	    String filename = "historyDetails.csv";
	    InputStreamResource file = new InputStreamResource(historyManagementService.load());

	    return ResponseEntity.ok()
	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	        .contentType(MediaType.parseMediaType("application/csv"))
	        .body(file);
	  }
	 
	 
	 
	 @GetMapping(value = "/v1/historic/all/{pageNumber}/{pageSize}")
	 public ResponseEntity<Map<String, Object>> getPaginated(@PathVariable Integer pageNumber,@PathVariable
	    		Integer pageSize) {
		 List<HistoryManagement> historyManagement = new ArrayList<HistoryManagement>();
		  int currpage = 1;
	        Slice<HistoryManagement> slice = historyManagementService.findAll(CassandraPageRequest.first(pageSize));
	        while(slice.hasNext() && currpage < pageNumber) {
	        	
	            slice = historyManagementService.findAll(slice.nextPageable());
	            currpage++;
	        }
	        
	        long count=historyManagementService.count();
	        int totalPagesCount=(int) (count/pageSize)+1;
	        Map<String, Object> response = new HashMap<>();
	        if(pageNumber>totalPagesCount)
	        {
	        	  return new ResponseEntity<>(response, HttpStatus.INSUFFICIENT_STORAGE);
	        }
	        response.put("historyManagement", slice.getContent());
	        response.put("currentPage",currpage );
	        response.put("totalItems", count);
	        response.put("itemsInPages", slice.get().count());
	        response.put("totalPagesCount", totalPagesCount);
	        return new ResponseEntity<>(response, HttpStatus.OK);
	     
	    }
	
	

}
