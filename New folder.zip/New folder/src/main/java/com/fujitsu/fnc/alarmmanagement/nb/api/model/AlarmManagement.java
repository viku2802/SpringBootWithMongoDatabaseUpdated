package com.fujitsu.fnc.alarmmanagement.nb.api.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;



import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
@Data
@Table("Fault")
public class AlarmManagement {

	@PrimaryKeyColumn(name="id",ordinal =0, type=PrimaryKeyType.PARTITIONED)
	private UUID id;
	@Override
	public String toString() {
		return "AlarmManagement [id=" + id + ", aid=" + aid + ", tid=" + tid + ", aidType=" + aidType
				+ ", neClearedDatTime=" + neClearedDatTime + ", severity=" + severity + ", conditionType="
				+ conditionType + ", conditionDesc=" + conditionDesc + ", location=" + location + ", direction="
				+ direction + ", serviceEffected=" + serviceEffected + ", faultType=" + faultType + ", conditionEffect="
				+ conditionEffect + ", aidDetail=" + aidDetail + "]";
	}
	@PrimaryKeyColumn(name="aid",ordinal =1, type=PrimaryKeyType.CLUSTERED)
	private String aid;
	private String tid;
	private String aidType;
	private String neClearedDatTime;
	private String severity;
	private String conditionType;
	private String conditionDesc;
	private String location;
	private String direction;
	private String serviceEffected;
	private String faultType;
	private String conditionEffect;
	private String aidDetail;
	
	
	
}
