package com.fujitsu.fnc.alarmmanagement.nb.api.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.search.suggest.SortBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataAccessException;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.dao.DuplicateKeyException;

import com.fujitsu.fnc.alarmmanagement.nb.api.model.AlarmManagement;

import com.fujitsu.fnc.alarmmanagement.nb.api.repository.AlarmManagementRepository;

import com.fujitsu.fnc.alarmmanagement.nb.api.service.AlarmManagementService;

@RestController
@RequestMapping("/api/alarm")
@EnableCassandraRepositories
public class AlarmManagementController {
	private static Logger logger = LogManager.getLogger(AlarmManagementController.class);
	private static final String DATABASE_DOWN = "Database service currently unavailable";
	@Autowired
	private AlarmManagementService alarmManagementService;
	
	@Autowired
	AlarmManagementRepository alarmManagementRepository;
   
	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;
	
	
	
	@PostMapping(value = "/v1/alarmmanagement", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody AlarmManagement alarmManagementServiceSchedule(
			@Valid @RequestBody AlarmManagement alarmManagement) throws Exception {
		try {
			AlarmManagement alarmManagementRes = alarmManagementService.alarmManagementServiceSchedule(alarmManagement);

			logger.info("HTTP POST SUCCESS: updated the alarmDetails, " + alarmManagementRes.toString());

			return alarmManagementRes;
		} catch (Exception e) {
			logger.error("HTTP POST FAILED: Couldn't updated the alarmDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	
	@GetMapping(value = "/v1/alarmmanagement/{aid}")
	public @ResponseBody AlarmManagement getAlarmDetails(@PathVariable("aid") String aid) throws Exception {
		try {

			AlarmManagement alarmManagement = alarmManagementService.getAlarmDetails(aid);

			logger.info("HTTP GET SUCCESS: alarmManagement :" + alarmManagement);

			return alarmManagement;
		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find alarmManagement ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	@GetMapping(value = "/v1/alarmmanagement/tid/{aid}")
	public @ResponseBody String getTid(@PathVariable("aid") String aid) throws Exception {
		try {

			AlarmManagement alarmManagement = alarmManagementService.getTid(aid);

			logger.info("HTTP GET SUCCESS: alarmManagement :" + alarmManagement);

			return alarmManagement.getTid();
		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find tidDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	@GetMapping(value = "/v1/alarmmanagement/alarmDetails/{severity}")
	public List<AlarmManagement> getAlarmDetailsSeverity(@PathVariable("severity") String severity)
			throws DuplicateKeyException, Exception {
		try {

			return alarmManagementService.getAlarmDetailsUsingSeverity(severity);

		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find alarmManagementDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}

	}
	

	@GetMapping(value = "/v1/alarmmanagement/SeverityCountDetails/{severity}")
	public Long countSeverity(@PathVariable("severity") String severity) throws Exception {
		try {

			Long count = alarmManagementService.countSeverityDetails(severity);
			return count;

		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find SeverityCountDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}

	}

	
	@GetMapping(value = "/v1/alarmmanagement/alarmDetailsByTid/{tid}")
	public List<AlarmManagement> getAlarmDetailsUsingTid(@PathVariable("tid") String tid) throws Exception {
		try {

			return (List<AlarmManagement>) alarmManagementService.getAlarmDetailsUsingTid(tid);

		} catch (Exception e) {
			logger.error("HTTP GET FAILED: Couldn't find alarmManagementDetails ", e);
			if (e instanceof DataAccessException) {
				throw new Exception(DATABASE_DOWN);
			} else {
				throw e;
			}
		}
	}

	
	
	 @GetMapping(value = "/v1/alarmmanagement/severityColumnValue") 
	 public void searchPersons()
	  {
		 int critical=0; int major=0;int warning=0;
		String comp="severity";
		List<AlarmManagement> list= alarmManagementRepository.findAll();
		 
		 List<Object> alarmManagement = Arrays.asList(list);
		 String s1=alarmManagement.toString();  
		 String s2[]=s1.split(s1);

	       /* for (String a : s2)
	            System.out.println(a.equalsIgnoreCase("severity"));*/
		 for (int i = 0; i < s2.length; i++) 
		    {
		    // if match found increase count
		    if (comp.equals(s2[i]))
		        major++;
		    }
		  
		
	        System.out.println(major);
		 
		 
	        
			/*
			 * Map<Object, Integer> hm = new HashMap<>();
			 * 
			 * for (Object i : customers) {
			 * 
			 * System.out.println(i.equals(customers)); }
			 */
	   // return alarmManagementRepository.searchPersons();
	  //  List<AlarmManagement> todos = new ArrayList<>();
       // todoRepository.findAll().forEach(todos::add);
        //return alarmManagement;
		//return null; 
	      
		  

	  }
	 
	
	
	 @GetMapping(value ="/v1/alarmmanagement/download-alarm-csv")
	  public ResponseEntity<Resource> getFile() {
	    String filename = "alarmDetails.csv";
	 //   DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
       // String currentDateTime = dateFormatter.format(new Date());
	    InputStreamResource file = new InputStreamResource(alarmManagementService.load());

	    return ResponseEntity.ok()
	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	        .contentType(MediaType.parseMediaType("application/csv"))
	        .body(file);
	  }
	 
	 
	 
	 @GetMapping(value = "/v1/alarmmanagement/all/{pageNumber}/{pageSize}")
	 public ResponseEntity<Map<String, Object>> getPaginated(@PathVariable Integer pageNumber,@PathVariable
	    		Integer pageSize) {
		 List<AlarmManagement> alarmManagement = new ArrayList<AlarmManagement>();
		  int currpage = 1;
	        Slice<AlarmManagement> slice = alarmManagementService.findAll(CassandraPageRequest.first(pageSize));
	        while(slice.hasNext() && currpage < pageNumber) {
	        	
	            slice = alarmManagementService.findAll(slice.nextPageable());
	            currpage++;
	        }
	        
	        long count=alarmManagementService.count();
	        long totalPagesCount=0;
	        if(pageSize>1)
	         totalPagesCount=(int) (count/pageSize)+1;
	        else
	        	totalPagesCount=count;
	        Map<String, Object> response = new HashMap<>();
	        if(pageNumber>totalPagesCount)
	        {
	        	  return new ResponseEntity<>(response, HttpStatus.INSUFFICIENT_STORAGE);
	        }
	        response.put("alarmManagement", slice.getContent());
	        response.put("currentPage",currpage );
	        response.put("totalItems", count);
	        response.put("itemsInPages", slice.get().count());
	        response.put("totalPagesCount", totalPagesCount);
	        return new ResponseEntity<>(response, HttpStatus.OK);
	     
	    }
	 
	 @GetMapping(value = "/v1/alarmmanagement/msg")
	 @Scheduled(fixedDelay = 3000)
	 public void broadcastNews(@PathVariable("message") String message) {
	   this.simpMessagingTemplate.convertAndSend("/topic/news", message);
	 }
	
	
	 
}
