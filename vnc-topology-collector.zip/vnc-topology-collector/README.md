This repository contains souce code to fetch data from VNC and push it to kafka.
