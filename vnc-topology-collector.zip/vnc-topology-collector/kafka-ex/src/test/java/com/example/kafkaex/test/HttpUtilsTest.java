package com.example.kafkaex.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.kafkaex.utils.HttpUtils;
import com.example.kafkaex.utils.HttpUtilsInterface;

//import com.javacodegeeks.mockitotutorial.basecode.EmptyCredentialsException;

@RunWith(MockitoJUnitRunner.class)
public class HttpUtilsTest {
	@Mock 
	private HttpUtilsInterface httputilsinterface;
	@InjectMocks
	private HttpUtils httputils;
	
	@Test
    public void testMockFunction()  {
    	String username = "admin";
    	String password = "admin";
    	when(this.httputilsinterface.createHeaders(username, password)).thenReturn(true);
    	boolean result = this.httputilsinterface.createHeaders("admin","admin");
    	assertTrue(result);
    }
}
