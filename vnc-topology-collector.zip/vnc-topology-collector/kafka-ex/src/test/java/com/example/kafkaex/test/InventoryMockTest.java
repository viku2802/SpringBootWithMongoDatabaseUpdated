package com.example.kafkaex.test;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.kafkaex.KafkaController;
import com.example.kafkaex.producer.InventoryProducer;

@RunWith(SpringRunner.class)
public class InventoryMockTest {
	
	@MockBean
	InventoryProducer ip;
	
	@Test
	public void getInvent() throws Exception{
		
		when(ip.getInventory()).thenReturn("http://167.254.205.14:8181/restconf/operational/opendaylight-inventory:nodes");
		String expected = "http://167.254.205.14:8181/restconf/operational/opendaylight-inventory:nodes";
		assertEquals(expected,ip.getInventory());
}
	@Test
	  public void testVoidMethodThrowingExcetion() {
	    Mockito.doThrow(new IllegalArgumentException()).when(ip).collectTopology(false);
	    ip.collectTopology(true);
	    Mockito.doThrow(new IllegalArgumentException()).when(ip).collectTopology(true);
	    try {
	    	ip.collectTopology(true);
	    	Assert.fail();
	    } catch (IllegalArgumentException e) {
	    	System.out.println(e);
	    }
	  }
}
