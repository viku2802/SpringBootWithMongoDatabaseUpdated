package com.example.kafkaex.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.kafkaex.producer.TopologyProducer;

@RunWith(SpringRunner.class)
public class TopologyMockTest {
	
	@MockBean
	TopologyProducer tp;
	
	@Test
	public void getTopo() throws Exception{
		
		when(tp.getTopology()).thenReturn("http://167.254.204.124:8181/restconf/operational/network-topology:network-topology");
		String expected = "http://167.254.204.124:8181/restconf/operational/network-topology:network-topology";
		assertEquals(expected,tp.getTopology());
		
	}
	@Test
	  public void testVoidMethodThrowingExcetion() {
	    Mockito.doThrow(new IllegalArgumentException()).when(tp).collectTopology(false);
	    tp.collectTopology(true);
	    Mockito.doThrow(new IllegalArgumentException()).when(tp).collectTopology(true);
	    try {
	    	tp.collectTopology(true);
	    	Assert.fail();
	    } catch (IllegalArgumentException e) {
	    	System.out.println(e);
	    }
	  }
	} 