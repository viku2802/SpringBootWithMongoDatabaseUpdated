package com.example.kafkaex;

import com.example.kafkaex.producer.TopologyProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/kafka")
@Profile("topology")
public class KafkaController {
    private final TopologyProducer topologyProducer;
    @Autowired
    public KafkaController(TopologyProducer topologyProducer) {
        this.topologyProducer = topologyProducer;
    }
    @PostMapping(value = "/publish")
    public void sendMessageToKafkaTopic(@RequestParam("message") String message){
        this.topologyProducer.sendMessage(message);
    }
}
