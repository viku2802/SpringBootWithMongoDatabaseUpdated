package com.example.kafkaex.producer;

import com.example.kafkaex.utils.HttpUtils;
import io.fujitsu.developer.Inventory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.http.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Profile("inventory")
public class InventoryProducer extends KafkaProducer {
    private static final Logger logger = LoggerFactory.getLogger(InventoryProducer.class);
    private final KafkaTemplate<String, Inventory> kafkaTemplate;

    public InventoryProducer(KafkaTemplate<String, Inventory> kafkaTemplate) {
        logger.info("==> enabling Inventory collector");
        this.kafkaTemplate = kafkaTemplate;
    }

    public String getInventory() {
        String response = "";
        logger.info("sending request for query topology : " + VNC_HOST + VNC_API);
        HttpHeaders headers = HttpUtils.createHeaders(username, password); 
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> exchange = restTemplate.exchange(VNC_HOST + VNC_API,
                HttpMethod.GET,
                entity,
                String.class);
        if (exchange.getStatusCode() == HttpStatus.OK) {
            response = exchange.getBody();
        } else {
            logger.error("request failed to communicate VNC");
        }
        return response;
    }

    @Scheduled(fixedRateString = "${fixedRate.in.milliseconds}")
    public void collectTopology() {
        String inventory = getInventory();
        Inventory.Builder builder = Inventory.newBuilder()
                .setInventory(inventory)
                .setTimestamp(LocalDateTime.now().toString());
        logger.info("sending request to kafka for writing on topic : " + topic);
        this.kafkaTemplate.send(topic, "topology", builder.build());
    }

	public void collectTopology(boolean b) {
	
		
	}
}
