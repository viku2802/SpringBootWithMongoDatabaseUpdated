package com.example.kafkaex.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.kafkaex.service.PMCollectorService;


@RestController
public class PMCollectorController {

	private static final Logger logger = LoggerFactory.getLogger(PMCollectorController.class);
	
	@Autowired
	PMCollectorService pmservice;

	@GetMapping("/")
	public String home() {
		return "At View Home Page";
	}

	@PostMapping("/receiver/pm")
	public void consumePM(@RequestBody String message) {
		logger.info("PM  received from VNC :"+message);
		pmservice.sendMessage(message);

	}

}
