package com.example.kafkaex.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import io.fujitsu.developer.PM;
import java.time.LocalDateTime;

import com.example.kafkaex.producer.KafkaProducer;


@Service
@Profile("inventory")
public class PMCollectorService extends KafkaProducer{

        private static final Logger logger = LoggerFactory.getLogger(PMCollectorService.class);

        private final KafkaTemplate<String, PM> kafkaTemplate;
        
        @Autowired
        public PMCollectorService(KafkaTemplate<String, PM> kafkaTemplate) {
            logger.info("==> enabling topology collector");
            this.kafkaTemplate = kafkaTemplate;
        }

        public void sendMessage(String message) {
                logger.info(String.format("$$ -> Sending PM message --> %s on topic %s",message,topic));
                PM.Builder builder = PM.newBuilder();
                builder.setPm(message);
                builder.setTimestamp(LocalDateTime.now().toString());
                this.kafkaTemplate.send(topic, "pm", builder.build());
        }
}
