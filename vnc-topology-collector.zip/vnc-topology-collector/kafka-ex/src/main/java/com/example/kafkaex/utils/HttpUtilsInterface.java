package com.example.kafkaex.utils;

public interface HttpUtilsInterface {
	
	public boolean createHeaders(String username, String password);
	

}
