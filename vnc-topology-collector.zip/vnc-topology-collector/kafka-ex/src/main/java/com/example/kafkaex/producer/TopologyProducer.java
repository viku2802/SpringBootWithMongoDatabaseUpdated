package com.example.kafkaex.producer;

import com.example.kafkaex.utils.HttpUtils;
import io.fujitsu.developer.Topology;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Profile("topology")
public class TopologyProducer extends KafkaProducer{
    private static final Logger logger = LoggerFactory.getLogger(TopologyProducer.class);
    private final KafkaTemplate<String, Topology> kafkaTemplate;



    @Autowired
    public TopologyProducer(KafkaTemplate<String, Topology> kafkaTemplate) {
        logger.info("==> enabling topology collector");
        this.kafkaTemplate = kafkaTemplate;
    }

    public String getTopology() {
        String response = "";
        logger.info("sending request for query topology : " + VNC_HOST + VNC_API);
        HttpHeaders headers = HttpUtils.createHeaders(username, password);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> exchange = restTemplate.exchange(VNC_HOST + VNC_API,
                HttpMethod.GET,
                entity,
                String.class);
        if (exchange.getStatusCode() == HttpStatus.OK) {
            //logger.info(String.format("--> topology: %s", exchange.getBody()));
            response = exchange.getBody();
        } else {
            logger.error("request failed to communicate VNC");
        }
        return response;
    }

    // TODO: source to be added which controller
    public void sendMessage(String message){
        logger.info(String.format("$$ -> Producing message --> %s",message));
        String topology = getTopology();
        Topology.Builder builder = Topology.newBuilder();
        builder.setTopology(topology);
        builder.setTimestamp(LocalDateTime.now().toString());
        this.kafkaTemplate.send(topic, "topology", builder.build());
    }

    @Scheduled(fixedRateString = "${fixedRate.in.milliseconds}")
    public void collectTopology() {
        String topology = getTopology();
        Topology.Builder builder = Topology.newBuilder()
                .setTopology(topology)
                .setTimestamp(LocalDateTime.now().toString());
        logger.info("sending request to kafka for writing on topic : " + topic);
        this.kafkaTemplate.send(topic, "topology", builder.build());
    }

	public void collectTopology(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
