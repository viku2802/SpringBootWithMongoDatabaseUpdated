package com.example.kafkaex.producer;

import io.fujitsu.developer.InventoryServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.http.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.example.kafkaex.utils.HttpUtils;

import java.time.LocalDateTime;

@Service
@Profile("inventoryservices")
public class InventoryServicesProducer extends KafkaProducer {
    private static final Logger logger = LoggerFactory.getLogger(InventoryServicesProducer.class);
    private final KafkaTemplate<String, InventoryServices> kafkaTemplate;

    public InventoryServicesProducer(KafkaTemplate<String, InventoryServices> kafkaTemplate) {
        logger.info("==> enabling Inventory Services collector");
        this.kafkaTemplate = kafkaTemplate;
    }

    private String getInventoryServices() {
        String response = "";
        logger.info("sending request for query inventory services : " + VNC_HOST + VNC_API);
        HttpHeaders headers = HttpUtils.createHeaders(username, password);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> exchange = restTemplate.exchange(VNC_HOST + VNC_API,
                HttpMethod.GET,
                entity,
                String.class);
        if (exchange.getStatusCode() == HttpStatus.OK) {
            response = exchange.getBody();
        } else {
            logger.error("request failed to communicate VNC");
        }
        return response;
    }
    
    @Scheduled(fixedRateString = "${fixedRate.in.milliseconds}")
    public void collectInventoryServices() {
        String inventoryservices = getInventoryServices();
        InventoryServices.Builder builder = InventoryServices.newBuilder()
                .setInventoryservices(inventoryservices)
                .setTimestamp(LocalDateTime.now().toString());
        logger.info("sending request to kafka for writing on topic : " + topic);
        this.kafkaTemplate.send(topic, "topology", builder.build());
    }
}

