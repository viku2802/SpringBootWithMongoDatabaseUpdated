package com.example.kafkaex.consumer;

import io.fujitsu.developer.InventoryServices;
import org.apache.avro.specific.SpecificData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.context.annotation.Profile;

@Service
@Profile("consumer")
public class InventoryServicesConsumer {
    private final Logger logger = LoggerFactory.getLogger(InventoryServicesConsumer.class);
    @KafkaListener(topics = "topic-inventory-services", groupId = "group_id_3")
    public void consume(ConsumerRecord<String, InventoryServices> record){
        logger.info("-> inventory services update received");
        logger.info(String.format("$$ -> Consumed Message -> %s",record.value()));
        InventoryServices inventoryservices = SpecificData.get().deepCopy(InventoryServices.SCHEMA$, record.value());
        logger.info(String.format("$$ -> Consumed Message -> %s", inventoryservices.getInventoryservices()));
    }
}

