package com.example.kafkaex.consumer;

import io.fujitsu.developer.Inventory;
import org.apache.avro.specific.SpecificData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.context.annotation.Profile;

@Service
@Profile("consumer")
public class InventoryConsumer {
    private final Logger logger = LoggerFactory.getLogger(InventoryConsumer.class);
    @KafkaListener(topics = "topic-inventory-2", groupId = "group_id_3")
    public void consume(ConsumerRecord<String, Inventory> record){
        logger.info("-> inventory update received");
        logger.info(String.format("$$ -> Consumed Message -> %s",record.value()));
        Inventory inventory = SpecificData.get().deepCopy(Inventory.SCHEMA$, record.value());
        logger.info(String.format("$$ -> Consumed Message -> %s", inventory.getInventory()));
    }
}
