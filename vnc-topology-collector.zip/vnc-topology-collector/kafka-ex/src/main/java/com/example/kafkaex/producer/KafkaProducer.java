package com.example.kafkaex.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

public abstract class KafkaProducer {
    @Autowired
    public RestTemplate restTemplate;

    @Value("${vnc.host}")
    public String VNC_HOST;

    @Value("${vnc.api}")
    public String VNC_API;

    @Value("${vnc.topic}")
    public String topic;

    @Value("${vnc.username}")
    public String username;

    @Value("${vnc.password}")
    public String password;
}
